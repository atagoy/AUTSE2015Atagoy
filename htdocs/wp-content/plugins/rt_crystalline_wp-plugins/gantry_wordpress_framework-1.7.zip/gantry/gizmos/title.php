<?php
/**
 * @version   1.7 October 16, 2010
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2010 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 */

defined('GANTRY_VERSION') or die();

gantry_import('core.gantrygizmo');

/**
 * @package     gantry
 * @subpackage  features
 */
class GantryGizmoTitle extends GantryGizmo {

    var $_name = 'title';

    function isEnabled(){
        return true;
    }


    function query_parsed_init() {
        global $gantry;

        // Single posts
        if (is_single()) {
            $gantry->pageTitle = single_post_title('', false) . ' | ' . get_bloginfo('name');

            // The home page or, if using a static front page, the blog posts page.
        } elseif (is_home() || is_front_page()) {
            $gantry->pageTitle = get_bloginfo('name');
            if (get_bloginfo('description'))
                $gantry->pageTitle .= ' | ' . get_bloginfo('description');

            // WordPress Pages
        } elseif (is_page()) {
            $gantry->pageTitle = single_post_title('', false) . ' | ' . get_bloginfo('name');

            // Search results
        } elseif (is_search()) {
            $gantry->pageTitle = _g('Search results for ') . '"' . get_search_query() . '"' . ' | ' . get_bloginfo('name');

            // 404 (Not Found)
        } elseif (is_404()) {
            $gantry->pageTitle = _g('Not Found') . ' | ' . get_bloginfo('name');

            // Otherwise:
        } else {
            $gantry->pageTitle = wp_title('', false) . ' | ' . get_bloginfo('name');
        }
    }
}