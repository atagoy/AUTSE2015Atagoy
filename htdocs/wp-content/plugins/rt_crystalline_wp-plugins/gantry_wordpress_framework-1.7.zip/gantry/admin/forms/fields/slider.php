<?php
/**
 * @version   1.7 October 16, 2010
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2010 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
defined('GANTRY_VERSION') or die();
/**
 * @package     gantry
 * @subpackage  admin.elements
 */
gantry_import('core.config.gantryformfield');

class GantryFormFieldSlider extends GantryFormField {

    protected $type = 'slider';
    protected $basetype = 'hidden';

	public function getInput()
	{
		global $gantry;
		$output = '';


		$this->template = end(explode(DS, $gantry->templatePath));

        $class = $this->element['class'] ? $this->element['class'] : '';
        $name = $this->element['name'] ? $this->element['name']:'';
        $node = $this->element;
        $control_name = $this->name;

		if (!defined('GANTRY_CSS')) {
			$gantry->addStyle($gantry->gantryUrl.'/admin/widgets/gantry.css');
			define('GANTRY_CSS', 1);
		}
        if (!defined('GANTRY_POSITIONS')) {
            $gantry->addScript($gantry->gantryUrl.'/admin/widgets/slider/js/slider.js');
			if (!defined('GANTRY_SLIDER')) define('GANTRY_SLIDER', 1);
        }

		$this->children = array();
		
		foreach($node->children() as $children) {
			$this->children[] = $children->data();
		}
		
		$scriptinit = $this->sliderInit($this->id);		
		$gantry->addDomReadyScript($scriptinit);
		
		$output = '
		<div class="wrapper">
		<div id="'.$this->id.'-wrapper" class="'.$class.'">
			<!--<div class="note">
				Internet Explorer 6 supports only the <strong>Low Quality</strong> setting.
			</div>-->
			<div class="slider">
			    <div class="slider2"></div>
				<div class="knob"></div>
			</div>
			<input type="hidden" id="'.$this->id.'" class="slider" name="'.$this->name.'" value="'.$this->value.'" />
		</div>
		</div>
		';
		
		return $output;
	}
	
	function sliderInit($name) {
		$name2 = str_replace("-", "_", $this->id);
		$steps = count($this->children) - 1;
		$current = array_search($this->value, $this->children);
		if ($current === false) $current = 0;
		
		$slider = "document.id('".$name."-wrapper').getElement('.slider')";
		$knob = "document.id('".$name."-wrapper').getElement('.knob')";
		$hidden = "document.id('$this->id')";
		$children = '[\'' . implode("', '", $this->children) . '\']';
		
		$js = "
			if (!window.sliders) window.sliders = {};
			$hidden.addEvents({
				'set': function(value) {
					var slider = window.sliders['".$name2."'];
					var index = slider.list.indexOf(value);

					slider.set(index).fireEvent('onComplete');
				}
			});
			window['sliders']['".$name2."'] = new RokSlider($slider, $knob, {
				steps: ".$steps.",
				snap: true,
				initialize: function() {
					this.hiddenEl = $hidden;
				},
				onComplete: function() {
					this.knob.removeClass('down');
					
					if (Gantry.MenuItemHead) {
						var cache = Gantry.MenuItemHead.Cache[Gantry.Selection];
						if (!cache) cache = new Hash({});
						cache.set('".$this->element['name']."', this.list[this.step]);
					}
				},
				onDrag: function(now) {
					this.element.getFirst().setStyle('width', now + 10);
				},
				onChange: function(step) {
					$hidden.setProperty('value', this.list[step]);
				},
				onTick: function(position) {
					if(this.options.snap) position = this.toPosition(this.step);
					this.knob.setStyle(this.property, position);
					this.fireEvent('onDrag', position);
				}
			});
			window['sliders']['".$name2."'].list = $children;
			window['sliders']['".$name2."'].set($current);
			
			$knob.addEvents({
				'mousedown': function() {this.addClass('down');},
				'mouseup': function() {this.removeClass('down');}
			});
		\n";
		
		return $js;
	}
}

?>