<?php
/**
 * @version   1.7 October 16, 2010
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2010 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
defined('GANTRY_VERSION') or die();


/**
 * Renders a toggle element
 *
 * @package     gantry
 * @subpackage  admin.elements
 */
gantry_import('core.config.gantryformfield');

class GantryFormFieldToggle extends GantryFormField {

    protected $type = 'toggle';
    protected $basetype = 'checkbox';

	public function getInput(){
		global $gantry;
		$hidden = '<input type="hidden" name="'.$this->name.'" value="_" />';
		
		$options = array ();
        $options[] = array('value'=>1,'text'=>'On/Off','id'=>$this->element->name);


		if (!defined('GANTRY_TOGGLE')) {
			$this->template = end(explode(DS, $gantry->templatePath));
			
            $gantry->addScript($gantry->gantryUrl.'/admin/widgets/toggle/js/touch.js');
            $gantry->addScript($gantry->gantryUrl.'/admin/widgets/toggle/js/toggle.js');
			$gantry->addScript($gantry->gantryUrl.'/admin/widgets/toggle/js/toggle-utils.js');
            define('GANTRY_TOGGLE',1);
        }

		
		$gantry->addDomReadyScript($this->toggleInit($this->id));
		
		$checked = ($this->value == 0) ? '' : 'checked="checked"';
		
		return "
		<div class=\"wrapper\">\n
			<input name=\"".$this->name."\" value=\"".$this->value."\" type=\"hidden\" />\n
			<input type=\"checkbox\" class=\"toggle\" id=\"".$this->id."\" $checked />\n
		</div>\n
		";
    }

	function toggleInit($id) {
		global $gantry;
		$js = "window.toggle".str_replace("-", "", $id)." = new Toggle('".$this->id."', {focus: true, onChange: GantryToggleChange});\n";
		
		return $js;
	}
}
