<?php
/**
 * @version   1.7 October 16, 2010
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2010 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
defined('GANTRY_VERSION') or die();
/**
 * @package     gantry
 * @subpackage  core.renderers
 */
gantry_import('core.renderers.gantrymodulesrenderer');
class GantryMainBodyRenderer  {
	// wrapper for mainbody display
    function display($bodyLayout = 'mainbody', $sidebarLayout = 'sidebar', $sidebarChrome = 'standard', $contentTopLayout = 'standard', $contentTopChrome = 'standard', $contentBottomLayout = 'standard', $contentBottomChrome = 'standard') {
        global $gantry;
        global $wp_registered_sidebars, $wp_registered_widgets;

        // get sidebar count
        $sidebars_widgets = wp_get_sidebars_widgets();
        $sidebarCount = GantryMainBodyRenderer::countSidebars($sidebars_widgets['sidebar']);
        $columnCount = $sidebarCount+1;
        
        //here we would see if the mainbody schema was set to soemthing else
        $defaultSchema     = $gantry->mainbodySchemas[GRID_SYSTEM][$columnCount];

        $mbp = $gantry->get('mainbodyPosition');
		$position = @unserialize($mbp);

        if (!$position || !isset($position[GRID_SYSTEM]) || !array_key_exists($columnCount,$position[GRID_SYSTEM])) $schema = $defaultSchema;
        else {
            $schema = $position[GRID_SYSTEM][$columnCount];
        }
        
        // If RTL then flip the array
        if (get_bloginfo('text_direction') == 'rtl' && $gantry->get('rtl-enabled')) {
        	$schema = $gantry->_flipBodyPosition($schema);
        }


        $classKey   = $gantry->_getKey($schema);
        $pushPull   = $gantry->pushPullSchemas[$classKey];

        $output         = '';
        $sidebars       = '';
        $contentTop     = null;
        $contentBottom  = null;

        $index = 1;
        // remove the mainbody and use the schema array for grid sizes
        $sidebarSchema = $schema;
        unset ($sidebarSchema['mb']);

        // Add extra data to sidebar
        $sidebar = &$wp_registered_sidebars['sidebar'];
        $sidebar['layout']=$sidebarLayout;
        $sidebar['chrome']=$sidebarChrome;

        // clean to max sidebars
        $filtered_widgets = GantryModulesRenderer::filterWidgetCount($sidebars_widgets);
        
        $widgets = $filtered_widgets['sidebar'];

        if (null == $widgets) $widgets = array();
        // Map widgets to sidebars without the dividers
        $widget_map = array();
        $pos = 1;
        $pos_info_set = false;

        if (get_bloginfo('text_direction') == 'rtl' && $gantry->get('rtl-enabled')) {
            $main_body_pp = array_shift($pushPull);
            $pushPull = array_reverse($pushPull);
            array_unshift($pushPull,$main_body_pp);
        }
    
        foreach($widgets as $widget) {
            if (!$pos_info_set) {
                $widget_map[$pos]['gridCount'] = current($sidebarSchema);
                $widget_map[$pos]['pushPull'] = $pushPull[$index++];
                $pos_info_set = true;
            }
            if (preg_match("/^gantrydivider/", $widget)){
                $pos++;
                $pos_info_set = false;
                next($sidebarSchema);
            }
            else
            {
                $widget_map[$pos]['widgets'][$widget]=array('name'=>$widget);
            }
        }

        $sidebar['widget_map'] = $widget_map;



        $sidebars = "";
        if (get_bloginfo('text_direction') == 'rtl' && $gantry->get('rtl-enabled')) {
            add_filter('sidebars_widgets', array('GantryMainBodyRenderer', 'invertPositionOrder'));
        }
        add_filter('dynamic_sidebar_params', array('GantryMainBodyRenderer', 'filterWidget'));
        ob_start();
        dynamic_sidebar('sidebar');
        $sidebars .= ob_get_clean();
        remove_filter('dynamic_sidebar_params', array('GantryMainBodyRenderer', 'filterWidget'));
        if (get_bloginfo('text_direction') == 'rtl' && $gantry->get('rtl-enabled')) {
            remove_filter('sidebars_widgets', array('GantryMainBodyRenderer', 'invertPositionOrder'));
        }
//        foreach($position_renders as $position => $contents){
//            if (empty($contents)) continue;
//            $sidebars .=  $gantry->renderLayout('mod_'.$sidebarLayout, array('contents'=>$contents, 'position'=>$position,'gridCount'=>current($sidebarSchema),'pushPull'=>$pushPull[$index++]));
//            next($sidebarSchema);
//        }


        // Add extra data to sidebar
//        $sidebar = &$wp_registered_sidebars['content-top'];
//        $sidebar['layout']=$contentTopLayout;
//        $sidebar['chrome']=$contentTopChrome;

//        $contentTop = "";
//
//        add_filter('dynamic_sidebar_params', array('GantryModulesRenderer', 'filterWidget'));
//        ob_start();
//        dynamic_sidebar('content-top');
//        $contentTop = ob_get_clean();
//        remove_filter('dynamic_sidebar_params', array('GantryModulesRenderer', 'filterWidget'));

        if ($gantry->countModules('content-top')) {     
            $contentTop = $gantry->displayModules('content-top',$contentTopLayout,$contentTopChrome,$schema['mb']);
        }

        if ($gantry->countModules('content-bottom')) {
            $contentBottom = $gantry->displayModules('content-bottom',$contentBottomLayout,$contentBottomChrome,$schema['mb']);
        }

        $output = $gantry->renderLayout('body_'.$bodyLayout, array('schema'=>$schema,'pushPull'=>$pushPull,'classKey'=>$classKey,
                                                        'sidebars'=>$sidebars, 'contentTop'=>$contentTop,
                                                        'contentBottom'=>$contentBottom));
        return $output;



    }

    function invertPositionOrder($sidebar_widgets){

        $inverted_sidebar_widgets = array();
        foreach ($sidebar_widgets as $position => $widgets) {
            $new_ordered = array();
            if (count($widgets) > 0){
                $last_divider = count($widgets);
                for ($i = count($widgets)-1; $i >= 0; $i--){
                    if (preg_match("/^gantrydivider/",$widgets[$i])){
                        for ($j = $i+1; $j<$last_divider; $j++){
                            $new_ordered[] = $widgets[$j];
                        }
                        $last_divider = $i;
                        $new_ordered[] = $widgets[$i];
                    }
                    else  if ($i == 0){
                        for ($j = 0; $j<$last_divider; $j++){
                            $new_ordered[] = $widgets[$j];
                        }
                    }
                }
            }
            $inverted_sidebar_widgets[$position]=$new_ordered;
        }
        return $inverted_sidebar_widgets;
    }

    function filterWidget($params) {
        global $gantry;

        $widget_id = $params[0]['widget_id'];
        $layout = $params[0]['layout'];
        
        // find the widget and its position
        foreach ($params[0]['widget_map'] as $pos => $position_info){
            $position_widgets = $position_info['widgets'];
            if (!array_key_exists($widget_id,$position_widgets)) continue;
            $params[0]['position'] = $pos;
            $params[0]['end'] = end(array_keys($position_widgets));
            $params[0]['start'] = reset(array_keys($position_widgets));
            break;
        }

        $params = $gantry->renderLayout('widget_'.$layout, $params);
        return $params;
    }

    function countSidebars($widgets) {
        global $gantry;
        $MAX_SIDEBARS = 3;
        // TODO  make this pull from templates xml
        $sidebar_count = 0;
        if (count($widgets) > 0) {
            $sidebar_count = 1;
            foreach ($widgets as $widget) {
                if (preg_match("/^gantrydivider/",$widget)){
                    $sidebar_count++;
                    if ($sidebar_count > $MAX_SIDEBARS) {
                        break;
                    }
                }
            }
        }
        return $sidebar_count ;
    }

}