<?php
/**
 * @version   1.7 October 16, 2010
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2010 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 */
gantry_import('core.rules.phprules.Fact');

class GantryPageCallFact extends Fact {
    public $query;
}