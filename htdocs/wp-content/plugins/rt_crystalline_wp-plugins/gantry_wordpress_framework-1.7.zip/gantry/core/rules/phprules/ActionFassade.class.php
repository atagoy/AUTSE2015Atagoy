<?php 
	class ActionFassade {
		
	}
 ?>