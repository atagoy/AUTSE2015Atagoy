<?php
/**
 * @version   1.7 October 16, 2010
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2010 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 * original copyright
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('GANTRY_VERSION') or die;


abstract class GantryFormGroup
{
    /**
	 * The description text for the form field.  Usually used in tooltips.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $description;

	/**
	 * The JXMLElement object of the <field /> XML element that describes the form field.
	 *
	 * @var		object
	 * @since	1.6
	 */
	protected $element;

	/**
	 * The JForm object of the form attached to the form field.
	 *
	 * @var		object
	 * @since	1.6
	 */
	protected $form;

	/**
	 * The form control prefix for field names from the JForm object attached to the form field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $formControl;

	/**
	 * The hidden state for the form field.
	 *
	 * @var		boolean
	 * @since	1.6
	 */
	protected $hidden;

	/**
	 * The document id for the form field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $id;

	/**
	 * The input for the form field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $input;

	/**
	 * The label for the form field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $label;

	/**
	 * The name of the form field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $name;

	/**
	 * The name of the field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $fieldname;

	/**
	 * The form field type.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $type;

    protected $basetype;

	/**
	 * The value of the form field.
	 *
	 * @var		mixed
	 * @since	1.6
	 */
	protected $value;

    protected $fields = array();

    protected $panel_position = 'left';

    protected $show_label = true;

    protected $variance = false;

    protected $prelabel_function = null;

    protected $postlabel_function = null;

    protected $setinoverride = true;

	/**
	 * Method to instantiate the form field object.
	 *
	 * @param	object	$form	The form to attach to the form field object.
	 *
	 * @return	void
	 * @since	1.6
	 */
	public function __construct($form = null)
	{
		// If there is a form passed into the constructor set the form and form control properties.
		if ($form instanceof GantryForm) {
			$this->form = $form;
			$this->formControl = $form->getFormControl();
		}
	}

	/**
	 * Method to get certain otherwise inaccessible properties from the form field object.
	 *
	 * @param	string	$name	The property name for which to the the value.
	 *
	 * @return	mixed	The property value or null.
	 * @since	1.6
	 */
	public function __get($name)
	{
		switch ($name) {
			case 'class':
			case 'description':
			case 'formControl':
			case 'id':
			case 'name':
			case 'type':
			case 'value':
			case 'fieldname':
            case 'panel_position':
            case 'show_label':
            case 'fields':
            case 'variance':
            case 'prelabel_funciton':
            case 'postlabel_funciton':
            case 'setinoverride':
            case 'basetype':
				return $this->$name;
				break;

            case 'input':
				// If the input hasn't yet been generated, generate it.
				if (empty($this->input)) {
					$this->input = $this->getInput();
				}

				return $this->input;
				break;
			case 'label':
				// If the label hasn't yet been generated, generate it.
				if (empty($this->label)) {
					$this->label = $this->getLabel();
				}

				return $this->label;
				break;
		}

		return null;
    }

    	/**
	 * Method to attach a JForm object to the field.
	 *
	 * @param	object	$form	The JForm object to attach to the form field.
	 *
	 * @return	object	The form field object so that the method can be used in a chain.
	 * @since	1.6
	 */
	public function setForm(GantryForm $form)
	{
		$this->form = $form;
		$this->formControl = $form->getFormControl();

		return $this;
	}

    /**
     * Method to attach a JForm object to the field.
     *
     * @param	object	$element	The JXMLElement object representing the <field /> tag for the
     * 								form field object.
     * @param	mixed	$value		The form field default value for display.
     * @param	string	$group		The field name group control value. This acts as as an array
     * 								container for the field. For example if the field has name="foo"
     * 								and the group value is set to "bar" then the full field name
     * 								would end up being "bar[foo]".
     *
     * @return	boolean	True on success.
     * @since	1.6
     */
    public function setup(& $element, $value, $group = null)
    {
        // Make sure there is a valid JFormField XML element.
        if (!($element instanceof GantrySimpleXMLElement) || (string) $element->getName() != 'fields') {
            return false;
        }

        // Reset the input and label values.
        $this->input = null;
        $this->label = null;

        // Set the xml element object.
        $this->element = $element;

        $this->fields = $this->form->getSubFields($this->element);

        foreach($this->fields as $field){
            if ($field->variance) $this->variance=true;
        }

        // Get some important attributes from the form field element.
        $id			= (string) $element['id'];
        $name		= (string) $element['name'];
        $type        = (string) $element['type'];
        $panel_position = (string) $element['panel_position'];
        $this->show_label = ((string) $element['show_label']=='false')?false:true;
        $this->setinoverride = ((string) $element['setinoverride']=='false')?false:true;

        // Set the field description text.
        $this->description	= (string) $element['description'];

        // Set the visibility.
        $this->hidden = ((string) $element['type'] == 'hidden' || (string) $element['hidden'] == 'true');

        // Set the field name and id.
        $this->fieldname 	= $name;
        $this->name			= $this->getName($name, $group);
        $this->id			= $this->getId($id, $name, $group);
        $this->type         = $type;

        if ($panel_position != null) $this->panel_position = $panel_position;

        // Set the field default value.
        $this->value = $value;

        return true;
    }

    /**
	 * Method to get the id used for the field input tag.
	 *
	 * @param	string	$fieldId	The field element id.
	 * @param	string	$fieldName	The field element name.
	 * @param	string	$group		The optional name of the group that the field element is a
	 * 								member of.
	 *
	 * @return	string	The id to be used for the field input tag.
	 * @since	1.6
	 */
	protected function getId($fieldId, $fieldName, $group = null)
	{

		// Initialize variables.
        $id = ($fieldId ? $fieldId : $fieldName);

       if (is_a($this->form->control,'WP_Widget')) {
            $id = $this->form->control->get_field_id($id);
        }
        else if (is_a($this->form->control,'GantryTemplateInfo')){
            $id = $this->form->control->get_field_id($id, $group);
        }

		return $id;
	}

    abstract public function getInput();

	/**
	 * Method to get the field label markup.
	 *
	 * @return	string	The field label markup.
	 * @since	1.6
	 */
	public function getLabel()
	{
		// Initialize variables.
		$label = '';

		// Get the label text from the XML element, defaulting to the element name.
		$text = $this->element['label'] ? (string) $this->element['label'] : (string) $this->element['name'];

		// Build the class for the label.
		$class = !empty($this->description) ? 'hasTip' : '';
		$class = $this->required == true ? $class.' required' : $class;

		// Add the opening label tag and main attributes attributes.
		$label .= '<label id="'.$this->id.'-lbl" class="'.$class.'"';

		// If a description is specified, use it to build a tooltip.
		if (!empty($this->description)) {
			$label .= ' title="'.htmlspecialchars(trim(_r($text), ':').'::' .
						_r($this->description), ENT_COMPAT, 'UTF-8').'"';
		}

		// Add the label text and closing tag.
		$label .= '>'._r($text).'</label>';

		return $label;
	}

	/**
	 * Method to get the name used for the field input tag.
	 *
	 * @param	string	$fieldName	The field element name.
	 * @param	string	$group		The optional name of the group that the field element is a
	 * 								member of.
	 *
	 * @return	string	The name to be used for the field input tag.
	 * @since	1.6
	 */
	protected function getName($fieldName, $group = null)
	{
		// Initialize variables.
		$name = '';

        if (is_a($this->form->control,'WP_Widget')) {
            $name = $this->form->control->get_field_name($fieldName);
        }
        else if (is_a($this->form->control,'GantryTemplateInfo')){
            $name = $this->form->control->get_field_name($fieldName, $group);
        }

		return $name;
	}

    public function setLabelWrapperFunctions($prelabel_function=null, $postlabel_function=null){
        $this->prelabel_function = $prelabel_function;
        $this->postlabel_function = $postlabel_function;
    }

    protected function preLabel($field){
        if ($this->prelabel_function == null || !function_exists($this->prelabel_function))
            return '';
        return call_user_func_array($this->prelabel_function, array($field));
    }

    protected function postLabel($field){
        if ($this->postlabel_function == null)
            return '';
        return call_user_func_array($this->postlabel_function, array($field));
    }
}