<?php
/**
 * @version   1.7 October 16, 2010
 * @author    RocketTheme http://www.rockettheme.com
 * @copyright Copyright (C) 2007 - 2010 RocketTheme, LLC
 * @license   http://www.gnu.org/licenses/gpl-2.0.html GNU/GPLv2 only
 *
 * derived from Joomla with original copyright and license
 * @copyright	Copyright (C) 2005 - 2010 Open Source Matters, Inc. All rights reserved.
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */
defined('GANTRY_VERSION') or die;


abstract class GantryFormField
{
	/**
	 * The description text for the form field.  Usually used in tooltips.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $description;

	/**
	 * The JXMLElement object of the <field /> XML element that describes the form field.
	 *
	 * @var		object
	 * @since	1.6
	 */
	public $element;

	/**
	 * The JForm object of the form attached to the form field.
	 *
	 * @var		object
	 * @since	1.6
	 */
	protected $form;

	/**
	 * The form control prefix for field names from the JForm object attached to the form field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $formControl;

	/**
	 * The hidden state for the form field.
	 *
	 * @var		boolean
	 * @since	1.6
	 */
	protected $hidden;

	/**
	 * The document id for the form field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $id;

	/**
	 * The input for the form field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $input;

	/**
	 * The label for the form field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $label;

	/**
	 * The multiple state for the form field.  If true then multiple values are allowed for the
	 * field.  Most often used for list field types.
	 *
	 * @var		boolean
	 * @since	1.6
	 */
	protected $multiple = false;

	/**
	 * The name of the form field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $name;

	/**
	 * The name of the field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $fieldname;

	/**
	 * The required state for the form field.  If true then there must be a value for the field to
	 * be considered valid.
	 *
	 * @var		boolean
	 * @since	1.6
	 */
	protected $required = false;

	/**
	 * The form field type.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $type;

    protected $basetype;

	/**
	 * The validation method for the form field.  This value will determine which method is used
	 * to validate the value for a field.
	 *
	 * @var		string
	 * @since	1.6
	 */
	protected $validate;

	/**
	 * The value of the form field.
	 *
	 * @var		mixed
	 * @since	1.6
	 */
	protected $value;

    protected $panel_position = 'left';

    protected $show_label = true;

    protected $base_value;
    protected $variance = false;
    protected $setinoverride = true;

	/**
	 * Method to instantiate the form field object.
	 *
	 * @param	object	$form	The form to attach to the form field object.
	 *
	 * @return	void
	 * @since	1.6
	 */
	public function __construct($form = null)
	{
		// If there is a form passed into the constructor set the form and form control properties.
		if ($form instanceof GantryForm) {
			$this->form = $form;
			$this->formControl = $form->getFormControl();
		}
	}

	/**
	 * Method to get certain otherwise inaccessible properties from the form field object.
	 *
	 * @param	string	$name	The property name for which to the the value.
	 *
	 * @return	mixed	The property value or null.
	 * @since	1.6
	 */
	public function __get($name)
	{
		switch ($name) {
			case 'class':
			case 'description':
			case 'formControl':
			case 'hidden':
			case 'id':
			case 'multiple':
			case 'name':
			case 'required':
			case 'type':
			case 'validate':
			case 'value':
			case 'fieldname':
            case 'panel_position':
            case 'show_label':
            case 'base_value':
            case 'setinoverride':
            case 'variance':
            case 'basetype':
				return $this->$name;
				break;

			case 'input':
				// If the input hasn't yet been generated, generate it.
				if (empty($this->input)) {
					$this->input = $this->getInput();
				}

				return $this->input;
				break;

			case 'label':
				// If the label hasn't yet been generated, generate it.
				if (empty($this->label)) {
					$this->label = $this->getLabel();
				}

				return $this->label;
				break;
		}

		return null;
    }

	/**
	 * Method to attach a JForm object to the field.
	 *
	 * @param	object	$form	The JForm object to attach to the form field.
	 *
	 * @return	object	The form field object so that the method can be used in a chain.
	 * @since	1.6
	 */
	public function setForm(GantryForm $form)
	{
		$this->form = $form;
		$this->formControl = $form->getFormControl();

		return $this;
	}

	/**
	 * Method to attach a JForm object to the field.
	 *
	 * @param	object	$element	The JXMLElement object representing the <field /> tag for the
	 * 								form field object.
	 * @param	mixed	$value		The form field default value for display.
	 * @param	string	$group		The field name group control value. This acts as as an array
	 * 								container for the field. For example if the field has name="foo"
	 * 								and the group value is set to "bar" then the full field name
	 * 								would end up being "bar[foo]".
	 *
	 * @return	boolean	True on success.
	 * @since	1.6
	 */
	public function setup(& $element, $value, $group = null)
	{
        global $gantry;

		// Make sure there is a valid JFormField XML element.
		if (!($element instanceof GantrySimpleXMLElement) || (string) $element->getName() != 'field') {
			return false;
		}

		// Reset the input and label values.
		$this->input = null;
		$this->label = null;

		// Set the xml element object.
		$this->element = $element;

		// Get some important attributes from the form field element.
		$class		= (string) $element['class'];
		$id			= (string) $element['id'];
		$multiple	= (string) $element['multiple'];
		$name		= (string) $element['name'];
		$required	= (string) $element['required'];
        $type        = (string) $element['type'];
        $panel_position = (string) $element['panel_position'];
        $this->show_label = ((string) $element['show_label']=='false')?false:true;
        $this->setinoverride = ((string) $element['setinoverride']=='false')?false:true;


        if (!empty($name)) {
            $groups = explode('.', $group);
            if (count($groups > 0)) {
                array_shift($groups);
                $groups[] = $name;
                $gantry_name = implode('-',$groups);
                $this->base_value = $gantry->get($gantry_name, null);

            }
        }

		// Set the required and validation options.
		$this->required	= ($required == 'true' || $required == 'required' || $required == '1');
		$this->validate	= (string) $element['validate'];

		// Add the required class if the field is required.
		if ($this->required) {
			if ($class) {
				if (strpos($class, 'required') === false) {
					$this->element['class'] = $class.' required';
				}
			} else {
				$this->element->addAttribute('class', 'required');
			}
		}

		// Set the multiple values option.
		$this->multiple = ($multiple == 'true' || $multiple == 'multiple');

		// Allow for field classes to force the multiple values option.
		if (isset($this->forceMultiple)) {
			$this->multiple = (bool) $this->forceMultiple;
		}

		// Set the field description text.
		$this->description	= (string) $element['description'];

		// Set the visibility.
		$this->hidden = ((string) $element['type'] == 'hidden' || (string) $element['hidden'] == 'true');

		// Set the field name and id.
		$this->fieldname 	= $name;
		$this->name			= $this->getName($name, $group);
		$this->id			= $this->getId($id, $name, $group);
        $this->type         = $type;

        if ($panel_position != null) $this->panel_position = $panel_position;

		// Set the field default value.
		$this->value = $value;
        if ($this->base_value != $this->value) $this->variance = true;
		return true;
	}

	/**
	 * Method to get the id used for the field input tag.
	 *
	 * @param	string	$fieldId	The field element id.
	 * @param	string	$fieldName	The field element name.
	 * @param	string	$group		The optional name of the group that the field element is a
	 * 								member of.
	 *
	 * @return	string	The id to be used for the field input tag.
	 * @since	1.6
	 */
	protected function getId($fieldId, $fieldName, $group = null)
	{

		// Initialize variables.
        $id = ($fieldId ? $fieldId : $fieldName);

       if (is_a($this->form->control,'WP_Widget')) {
            $id = $this->form->control->get_field_id($id);
        }
        else if (is_a($this->form->control,'GantryTemplateInfo')){
            $id = $this->form->control->get_field_id($id, $group);
        }

		return $id;
	}

	/**
	 * Method to get the field input markup.
	 *
	 * @return	string	The field input markup.
	 * @since	1.6
	 */
	abstract public function getInput();

	/**
	 * Method to get the field label markup.
	 *
	 * @return	string	The field label markup.
	 * @since	1.6
	 */
	protected function getLabel()
	{
		// Initialize variables.
		$label = '';

		// Get the label text from the XML element, defaulting to the element name.
		$text = $this->element['label'] ? (string) $this->element['label'] : (string) $this->element['name'];

		// Build the class for the label.
		$class = !empty($this->description) ? 'hasTip' : '';
		$class = $this->required == true ? $class.' required' : $class;

		// Add the opening label tag and main attributes attributes.
		$label .= '<label id="'.$this->id.'-lbl" class="'.$class.'"';

		// If a description is specified, use it to build a tooltip.
		if (!empty($this->description)) {
			$label .= ' title="'.htmlspecialchars(trim(_r($text), ':').'::' .
						_r($this->description), ENT_COMPAT, 'UTF-8').'"';
		}

		// Add the label text and closing tag.
		$label .= '>'._r($text).'</label>';

		return $label;
	}

	/**
	 * Method to get the name used for the field input tag.
	 *
	 * @param	string	$fieldName	The field element name.
	 * @param	string	$group		The optional name of the group that the field element is a
	 * 								member of.
	 *
	 * @return	string	The name to be used for the field input tag.
	 * @since	1.6
	 */
	protected function getName($fieldName, $group = null)
	{
		// Initialize variables.
		$name = '';

        if (is_a($this->form->control,'WP_Widget')) {
            $name = $this->form->control->get_field_name($fieldName);
        }
        else if (is_a($this->form->control,'GantryTemplateInfo')){
            $name = $this->form->control->get_field_name($fieldName, $group);
        }

		return $name;
	}
}
